package com.example.cyberlock

import android.app.KeyguardManager
import android.content.Context
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

class LockScreenActivity : AppCompatActivity() {

    // SHA-256 хэш от пароля "789456"
    private val TARGET_HASH = "290b9921c396387b7561784f9e2f20b56c6f16d474518442f010b82a29d23d77"
    private var failedAttempts = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyCyberpunkWindowFlags()
        setContentView(R.layout.activity_lock_screen)

        val etPinCode = findViewById<EditText>(R.id.etPinCode)
        val btnUnlock = findViewById<Button>(R.id.btnUnlock)
        val tvHint = findViewById<TextView>(R.id.tvHint)

        btnUnlock.setOnClickListener {
            val code = etPinCode.text.toString()
            if (sha256(code) == TARGET_HASH) {
                successUnlock()
            } else {
                handleWrongPin(tvHint, etPinCode)
            }
        }
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun handleWrongPin(tvHint: TextView, etPinCode: EditText) {
        failedAttempts++
        vibratePhone()
        tvHint.text = "[ ОШИБКА: ДОСТУП ОТКЛОНЕН ($failedAttempts/3) ]"
        tvHint.setTextColor(Color.parseColor("#FF0055"))
        etPinCode.setText("")
    }

    private fun successUnlock() {
        Toast.makeText(this, "ДОСТУП РАЗРЕШЕН", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun vibratePhone() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(200)
        }
    }

    private fun applyCyberpunkWindowFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
            km.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        )
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_HOME) return true
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}
}
